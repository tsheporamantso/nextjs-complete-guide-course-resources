export default function FeedLoading() {
  return <p>Loading feed data...</p>;
}
